package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

public class Main
{

    private static final int NUM_RUNS = 10;

    public static int[] readCSV(String filePath, int columnIndex) {
        List<Integer> data = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            br.readLine();
            String line;

            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(",", -1);
                if (tokens.length > columnIndex && !tokens[columnIndex].isEmpty()) {
                    try {
                        data.add(Integer.parseInt(tokens[columnIndex].trim()));
                    } catch (NumberFormatException e) {

                    }
                }
            }
        } catch (IOException e) {
            System.err.println("OOPS! Error occurred: " + e.getMessage());
        }

        return data.stream().mapToInt(i -> i).toArray();
    }


    public static void combSort(int[] arr) {
        int n = arr.length;
        int gap = n;
        boolean swapped = true;

        while (gap != 1 || swapped) {
            gap = (gap * 10) / 13;
            if (gap < 1) gap = 1;

            swapped = false;

            for (int i = 0; i < n - gap; i++) {
                if (arr[i] > arr[i + gap]) {
                    int temp = arr[i];
                    arr[i] = arr[i + gap];
                    arr[i + gap] = temp;
                    swapped = true;
                }
            }
        }
    }



    public static void insertionSort(int[] arr) {
        for (int j = 1; j < arr.length; j++) {
            int key = arr[j];
            int i = j - 1;
            while (i >= 0 && arr[i] > key) {
                arr[i + 1] = arr[i];
                i = i - 1;
            }
            arr[i + 1] = key;
        }
    }

    public static void shakerSort(int[] arr) {
        boolean swapped = true;

        while (swapped) {
            swapped = false;
            for (int i = 0; i < arr.length - 1; i++) {
                if (arr[i] > arr[i + 1]) {
                    int temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) break;

            swapped = false;
            for (int i = arr.length - 2; i >= 0; i--) {
                if (arr[i] > arr[i + 1]) {
                    int temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                    swapped = true;
                }
            }
        }
    }

    public static void shellSort(int[] arr) {
        int n = arr.length;
        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j = i;
                while (j >= gap && arr[j - gap] > temp) {
                    arr[j] = arr[j - gap];
                    j -= gap;
                }
                arr[j] = temp;
            }
        }
    }

    public static void radixSort(int[] A) {
        int d = getMaxDigits(A);

        for (int pos = 1; pos <= d; pos++) {
            A = countingSort(A, pos);
        }
    }


    private static int getMaxDigits(int[] A) {
        int max = Arrays.stream(A).max().orElse(0);
        return (int) Math.log10(max) + 1;
    }


    private static int[] countingSort(int[] A, int pos) {
        int size = A.length;
        int[] output = new int[size];
        int[] count = new int[10];


        for (int i = 0; i < size; i++) {
            int digit = getDigit(A[i], pos);
            count[digit]++;
        }


        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }


        for (int i = size - 1; i >= 0; i--) {
            int digit = getDigit(A[i], pos);
            output[count[digit] - 1] = A[i];
            count[digit]--;
        }

        return output;
    }


    private static int getDigit(int num, int pos) {
        return (num / (int) Math.pow(10, pos - 1)) % 10;
    }

    public static void showAndSaveChart(String title, int[] xAxis, double[][] yAxis,boolean isSortBased) throws IOException {
        XYChart chart = new XYChartBuilder().width(800).height(600).title(title)
                .yAxisTitle("Time in Milliseconds").xAxisTitle("Input Size").build();

        double[] doubleX = Arrays.stream(xAxis).asDoubleStream().toArray();

        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);


        String[] sortNames = {"Comb", "Insertion", "Shaker", "Shell", "Radix"};
        String[] dataTypes = {"Random", "Sorted", "Reversed"};

        String[] legends = isSortBased ? sortNames : dataTypes;

        for (int i = 0; i < yAxis.length; i++) {
            chart.addSeries(legends[i], doubleX, yAxis[i]);
        }

        BitmapEncoder.saveBitmap(chart, title + ".png", BitmapEncoder.BitmapFormat.PNG);
        new SwingWrapper(chart).displayChart();
    }

    public static double measureExecutionTime(Runnable algorithm, int iterations) {
        long totalDuration = 0;

        for (int i = 0; i < iterations; i++) {
            long startTime = System.nanoTime();
            algorithm.run();
            totalDuration += System.nanoTime() - startTime;
        }

        return totalDuration / (iterations * 1_000_000.0);
    }

    public static int[] reverseArray(int[] array) {
        int[] reversed = new int[array.length];
        for(int i = 0; i < array.length; i++){
            reversed[i] = array[array.length - 1 - i];
        }
        return reversed;
    }

    public static void displayResults(String header, int[] sizes, double[][] results) {
        System.out.println("\n=== " + header + " ===");
        System.out.print("Input Size\t");

        String[] algorithms = {"Comb", "Insertion", "Shaker", "Shell", "Radix"};
        for (String algo : algorithms) {
            System.out.print(algo + "\t");
        }
        System.out.println();

        for (int i = 0; i < sizes.length; i++) {
            System.out.printf("%d\t", sizes[i]);
            for (double[] result : results) {
                System.out.printf("%.2f\t", result[i]);
            }
            System.out.println();
        }
    }

    public static void evaluateSortAlgo(int[] csvData, int[] inputAxis) {
        String[] sortNames = {"Comb", "Insertion", "Shaker", "Shell", "Radix"};
        String[] dataNames = {"Random", "Sorted", "Reversed"};
        Map<String, double[]> randomTimes = new HashMap<>();
        Map<String, double[]> sortedTimes = new HashMap<>();
        Map<String, double[]> reversedTimes = new HashMap<>();

        for (String sort : sortNames) {
            randomTimes.put(sort, new double[inputAxis.length]);
            sortedTimes.put(sort, new double[inputAxis.length]);
            reversedTimes.put(sort, new double[inputAxis.length]);
        }

        Map<Integer, int[]> sortedArraysMap = new HashMap<>();

        for (int i = 0; i < inputAxis.length; i++) {
            int size = inputAxis[i];
            int[] randomData = Arrays.copyOf(csvData, size);
            System.out.println("Testing size: " + size);


            for (String sort : sortNames) {
                randomTimes.get(sort)[i] = measureExecutionTime(() -> applySort(sort, Arrays.copyOf(randomData, size)), NUM_RUNS);
            }


            int[] sortedData = Arrays.copyOf(randomData, size);
            Arrays.sort(sortedData);
            sortedArraysMap.put(size, sortedData);

            for (String sort : sortNames) {
                sortedTimes.get(sort)[i] = measureExecutionTime(() -> applySort(sort, Arrays.copyOf(sortedData, size)), NUM_RUNS);
            }


            int[] reversedData = reverseArray(sortedData);
            for (String sort : sortNames) {
                reversedTimes.get(sort)[i] = measureExecutionTime(() -> applySort(sort, Arrays.copyOf(reversedData, size)), NUM_RUNS);
            }
        }


        displayResults("Random Data Analysis", inputAxis, convertMapToArray(randomTimes, sortNames));
        displayResults("Sorted Data Analysis", inputAxis, convertMapToArray(sortedTimes, sortNames));
        displayResults("Reversed Data Analysis", inputAxis, convertMapToArray(reversedTimes, sortNames));


        try {
            showAndSaveChart("Random Data Analysis", inputAxis, convertMapToArray(randomTimes, sortNames),true);
            showAndSaveChart("Sorted Data Analysis", inputAxis, convertMapToArray(sortedTimes, sortNames),true);
            showAndSaveChart("Reversed Data Analysis", inputAxis, convertMapToArray(reversedTimes, sortNames),true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Sorting Algorithms in sortNames:");
        for (String sort : sortNames) {
            try {
                double[][] sortPerformance = new double[3][];
                sortPerformance[0] = randomTimes.get(sort);
                sortPerformance[1] = sortedTimes.get(sort);
                sortPerformance[2] = reversedTimes.get(sort);


                for (int i = 0; i < sortPerformance.length; i++) {
                    System.out.println(sort + " Data " + i + ": " + Arrays.toString(sortPerformance[i]));
                }


                showAndSaveChart(sort + " Sort Performance", inputAxis, sortPerformance,false);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public static double[][] convertMapToArray(Map<String, double[]> map, String[] keys) {
        double[][] result = new double[keys.length][];
        for (int i = 0; i < keys.length; i++) {
            result[i] = map.get(keys[i]);
        }
        return result;
    }


    public static void applySort(String sortType, int[] array) {
        switch (sortType) {
            case "Comb": combSort(array); break;
            case "Insertion": insertionSort(array); break;
            case "Shaker": shakerSort(array); break;
            case "Shell": shellSort(array); break;
            case "Radix": radixSort(array); break;
        }
    }


    public static void main(String[] args) throws IOException {
        int[] inputAxis = {500, 1000, 2000, 4000, 8000,16000,32000, 64000, 128000, 250000};
        String filePath = "src/main/resources/TrafficFlowDataset.csv";
        int[] csvData = readCSV(filePath, 2);


        evaluateSortAlgo(csvData, inputAxis);
        System.out.println("Toplam okunan veri sayısı: " + csvData.length);


    }

}